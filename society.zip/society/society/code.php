<?php

$connection = mysqli_connect("localhost", "root", "", "society_management");

if(isset($_POST['submit']))
{
    $name = $_POST['name'];
    $flat_number = $_POST['flat_number'];
    $tenants = $_POST['tenants'];
    $flat_type = $_POST['flat_type'];

    $query = "INSERT INTO rent(name, flat_number, tenants, flat_type) VALUES('$name', '$flat_number', '$tenants', '$flat_type')";

    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        echo "<script type='text/javascript'>alert('House for rent added');</script>";
        header("location: admin_service_dashboard.php");
    }

    else{
        echo "<script type='text/javascript'>alert('House for rent not added');</script>";
        header("location: addrent.php");
    }

}

?>