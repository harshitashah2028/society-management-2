<?php

session_start();

// $userloginid=$_SESSION["userid"] = $_GET['userlogid'];
// echo $_SESSION["userid"];


?>


<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <![endif]-->
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin Dashboard</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="styles.css">

</head>
<style>
    body {
        background-image: url('images/1.jpg');
        background-size: cover;
    }

    .innerright,
    label {
        color: dimgrey;
        font-weight: bold;
    }

    .container,
    .imglogo {
        margin: auto;
    }

    .row {
        /* margin: auto; */
        padding-bottom: 20px;
    }

    .innerdiv {
        text-align: center;
        /* width: 500px; */
        margin: 10px;
    }

    input {
        margin-left: 20px;
    }

    .leftinnerdiv {
        float: left;
        width: 25%;
    }

    .rightinnerdiv {
        float: right;
        width: 75%;
    }

    /* 
.innerright {
    background-color: 
} */

    .greenbtn {
        background-color: dimgrey;
        color: white;
        width: 95%;
        height: 40px;
        margin-top: 8px;
    }

    .greenbtn,
    a {
        text-decoration: none;
        color: white;
        font-size: large;
    }

    th {
        background-color: orange;
        color: black;
    }

    td {
        background-color: #fed8b1;
        color: black;
    }

    td,
    a {
        color: black;
    }
</style>

<body>


    <?php
    include("data_class.php");
    $msg = "";

    if (!empty($_REQUEST['msg'])) {
        $msg = $_REQUEST['msg'];
    }

    if ($msg == "done") {
        echo "<div class='alert alert-success' role='alert'>Sucssefully Done</div>";
    } elseif ($msg == "fail") {
        echo "<div class='alert alert-danger' role='alert'>Fail</div>";
    }
    ?>
    <div class="container">
        <div class="innerdiv">
            <div class="row"><img class="imglogo" src="images/society.png" /></div>
            <div class="leftinnerdiv">
                
                <!--<Button class="greenbtn">Welcome</Button>
                <Button class="greenbtn" onclick="openpart('myaccount')"> My Account</Button>
                <Button class="greenbtn" onclick="openpart('complain')"> Add Complain</Button>
                <Button class="greenbtn" onclick="openpart('payMen')"> Pay Maintenance </Button>
                <a href="userrent.php"><Button class="greenbtn">Houses on Rent</Button></a>
                <a href="index.php"><Button class="greenbtn"> LOGOUT</Button></a>-->

                <Button class="greenbtn">Welcome</Button>
                <Button class="greenbtn" onclick="openpart('myaccount')"> My Account</Button>
                <Button class="greenbtn" onclick="openpart('complain')"> Add Complain</Button>
                <Button class="greenbtn" onclick="openpart('payMen')"> Pay Maintenance </Button>
                <a href="userrent.php"><Button class="greenbtn"> Houses on Rent</Button></a>
                <a href="index.php"><Button class="greenbtn"> LOGOUT</Button></a>
            </div>

            <?php

    $connection = mysqli_connect("localhost", "root", "", "society_management");
    
    $query = "SELECT * FROM rent";

    $query_run = mysqli_query($connection, $query);
    
    ?>


            <?php
        
        if(mysqli_num_rows($query_run) > 0)
        {
          while($row = mysqli_fetch_assoc($query_run))
          {
           ?>

            <div class="cardbs">

            <div class="card" style="width: 18rem;">
                <!-- <img src="..." class="card-img-top" alt="..."> -->
                <div class="card-body">
                    <h5 class="card-title">RENT HOUSE</h5>
                    <p class="card-text">Owner's name: <?php  echo $row['name'];  ?></p>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">Flat no: <?php echo $row['flat_number'];?></li>
                    <li class="list-group-item">Tenants: <?php echo $row['tenants'];?></li>
                    <li class="list-group-item">Flat type: <?php echo $row['flat_type'];?></li>
                </ul>
                <!-- <div class="card-body">
                    <a href="#" class="card-link">Card link</a>
                    <a href="#" class="card-link">Another link</a>
                </div> -->
            </div>

            </div><br>
            <?php
        }
      }
      else{
        echo "no records found";
      }
          ?>


            <div class="rightinnerdiv">
                <div id="complain" class="innerright portion" style="display:none">
                    <Button class="greenbtn">ADD COMPLAIN</Button>
                    <form action="add_complain.php" method="post" enctype="form-data">
                        <label>Name:</label><input type="text" name="name" />
                        </br>
                        <label>Complaint:</label><input type="text" name="complain" />
                        </br>
                        <input type="submit" value="SUBMIT" />
                    </form>
                </div>
            </div>


            <div class="rightinnerdiv">
                <div id="payMen" class="innerright portion" style="display:none">
                    <?php
                    $u = new data;
                    $u->setconnection();
                    $u->getAmount($flat_no);
                    $recordset = $u->getAmount($flat_no);
                    foreach ($recordset as $row) {
                        $amount_paid = $row[3];
                        $pending_amount = $row[2];
                        $flat_no = $row[0];
                    }
                    ?>
                    <Button class="greenbtn">PAY MAINTENANCE</Button>

                    <p style="color:black"><u>Pending Amount:</u> &nbsp&nbsp<?php echo $pending_amount  ?></p>

                    <form action="payAmount.php" method="post" enctype="form-data">
                        <label>Amount:</label><input type="text" name="amount" />
                        </br>
                        <input type="hidden" name="flat_no" value="<?php echo $flat_no ?>">
                        <input type="hidden" name="pending_amount" value="<?php echo $pending_amount ?>">
                        <input type="hidden" name="amount_paid" value="<?php echo $amount_paid ?>">
                        <input type="hidden" name="userid" value="<?php echo $userloginid ?>">

                        <input type="submit" value="SUBMIT" />
                    </form>
                </div>
            </div>


        </div>
    </div>


    <script>
        function openpart(portion) {
            var i;
            var x = document.getElementsByClassName("portion");
            for (i = 0; i < x.length; i++) {
                x[i].style.display = "none";
            }
            document.getElementById(portion).style.display = "block";
        }
    </script>


</body>

<style>

        .cardbs{
            margin-left: 20em;
        }


</style>

</html>