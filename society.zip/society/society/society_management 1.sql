-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2023 at 06:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `society_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(110) NOT NULL,
  `email` varchar(110) NOT NULL,
  `Pass` varchar(110) NOT NULL,
  `type` int(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `Pass`, `type`) VALUES
(1, 'akash30nair@gmail.com', '12345', 0);

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `complains` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`id`, `name`, `complains`) VALUES
(5, 'Vivek', 'Water shortage since last 2 days'),
(6, 'SANTOSH', 'Too much noice from top floor'),
(8, 'Anjali Nair', 'Pipe leakage'),
(9, 'Akash', 'water supply shortage'),
(10, 'Akash', 'Electricity issue');

-- --------------------------------------------------------

--
-- Table structure for table `flat_details`
--

CREATE TABLE `flat_details` (
  `flat_no` varchar(5) NOT NULL,
  `name` varchar(30) NOT NULL,
  `family_member` int(10) NOT NULL,
  `flat_type` varchar(10) NOT NULL,
  `vehicle` varchar(10) NOT NULL,
  `no_of_vehicle` int(10) NOT NULL,
  `contact_number` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `flat_details`
--

INSERT INTO `flat_details` (`flat_no`, `name`, `family_member`, `flat_type`, `vehicle`, `no_of_vehicle`, `contact_number`) VALUES
('1', 'VISHNU ACHARY', 4, ' 3BHK', 'BIKE', 2, 123456789),
('2', 'SANTOSH INGLE', 4, '3BHK', 'BIKE', 2, 987654321),
('3', 'SOORAJ SUKUMARAN', 4, '3 BHK', 'CAR', 1, 123459876),
('4', 'AKASH NAIR', 4, '2BHK', 'CAR', 1, 987612345),
('5', 'A', 2, '2BHK', 'car', 2, 1928364677);

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `flat_no` int(10) NOT NULL,
  `owner_name` varchar(30) NOT NULL,
  `pending_amount` float NOT NULL,
  `amount_paid` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `maintenance`
--

INSERT INTO `maintenance` (`flat_no`, `owner_name`, `pending_amount`, `amount_paid`) VALUES
(1, 'Vishnu Achary', 0, 9000),
(2, 'Anjali Nair', 5000, 2000),
(101, 'absgd', 2000, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `memberdata`
--

CREATE TABLE `memberdata` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `flat_no` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `memberdata`
--

INSERT INTO `memberdata` (`id`, `name`, `email`, `pass`, `flat_no`) VALUES
(1, 'Akash Nair', 'aaakash30nair@gmail.com', '12345', 1),
(3, 'Sooraj Sukumaran', 'Sooraj@1234', '123456', 15),
(4, 'Ashutosh', 'Ashutosh@12345', '12345', 11);

-- --------------------------------------------------------

--
-- Table structure for table `rent`
--

CREATE TABLE `rent` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `flat_number` varchar(255) NOT NULL,
  `tenants` varchar(255) NOT NULL,
  `flat_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rent`
--

INSERT INTO `rent` (`id`, `name`, `flat_number`, `tenants`, `flat_type`) VALUES
(1, 'Akash', '37', '5', '1BHK'),
(2, 'harshali', '58', '4', 'RK');

-- --------------------------------------------------------

--
-- Table structure for table `view_maintenence`
--

CREATE TABLE `view_maintenence` (
  `flat_no` int(10) NOT NULL,
  `Amount_paid` int(10) NOT NULL,
  `pending_amount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flat_details`
--
ALTER TABLE `flat_details`
  ADD PRIMARY KEY (`flat_no`);

--
-- Indexes for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`flat_no`);

--
-- Indexes for table `memberdata`
--
ALTER TABLE `memberdata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rent`
--
ALTER TABLE `rent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `view_maintenence`
--
ALTER TABLE `view_maintenence`
  ADD PRIMARY KEY (`flat_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `memberdata`
--
ALTER TABLE `memberdata`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rent`
--
ALTER TABLE `rent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
